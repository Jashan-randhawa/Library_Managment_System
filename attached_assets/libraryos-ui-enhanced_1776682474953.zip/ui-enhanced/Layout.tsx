import { useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard, BookOpen, Users, BookMarked,
  CalendarCheck, AlertCircle, Library, ChevronRight, Menu, X,
} from "lucide-react";
import { cn } from "../lib/utils";

const navItems = [
  { to: "/", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/books", icon: BookOpen, label: "Books" },
  { to: "/members", icon: Users, label: "Members" },
  { to: "/loans", icon: BookMarked, label: "Loans" },
  { to: "/reservations", icon: CalendarCheck, label: "Reservations" },
  { to: "/fines", icon: AlertCircle, label: "Fines" },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="px-5 py-5 border-b" style={{ borderColor: "var(--border-subtle)" }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center relative overflow-hidden"
            style={{ background: "linear-gradient(135deg, #f59e0b, #d97706)", boxShadow: "0 4px 15px rgba(245,158,11,0.35)" }}>
            <Library className="w-4.5 h-4.5 text-black relative z-10" />
          </div>
          <div>
            <p className="font-serif text-base leading-tight" style={{ color: "var(--text-primary)" }}>LibraryOS</p>
            <p className="text-xs" style={{ color: "var(--text-muted)" }}>Management System</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-5 space-y-0.5 overflow-y-auto">
        <p className="text-xs font-semibold uppercase tracking-widest px-3 mb-3" style={{ color: "var(--text-muted)" }}>Navigation</p>
        {navItems.map(({ to, icon: Icon, label }) => {
          const isActive = to === "/" ? location.pathname === "/" : location.pathname.startsWith(to);
          return (
            <NavLink
              key={to}
              to={to}
              onClick={() => setMobileOpen(false)}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group relative",
                isActive ? "text-black" : "hover:text-white"
              )}
              style={isActive ? {
                background: "linear-gradient(135deg, #f59e0b, #d97706)",
                boxShadow: "0 4px 15px rgba(245,158,11,0.25)",
                color: "#000"
              } : {
                color: "var(--text-secondary)"
              }}
              onMouseEnter={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.05)"; }}
              onMouseLeave={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = ""; }}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              <span className="flex-1">{label}</span>
              {isActive && <ChevronRight className="w-3 h-3 opacity-60" />}
            </NavLink>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-4 py-4 border-t" style={{ borderColor: "var(--border-subtle)" }}>
        <div className="flex items-center gap-3 px-2 py-2 rounded-xl" style={{ background: "var(--accent-amber-soft)" }}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
            style={{ background: "linear-gradient(135deg, #f59e0b44, #d97706aa)" }}>
            <span className="text-xs font-bold" style={{ color: "#f59e0b" }}>LB</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium truncate" style={{ color: "var(--text-primary)" }}>Librarian</p>
            <p className="text-xs truncate" style={{ color: "var(--text-muted)" }}>admin@library.in</p>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden mesh-bg">
      {/* Desktop Sidebar */}
      <aside className="w-60 flex-shrink-0 hidden md:flex flex-col relative"
        style={{ background: "var(--bg-surface)", borderRight: "1px solid var(--border-subtle)" }}>
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden animate-fade-in">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <aside className="absolute left-0 top-0 h-full w-60 z-10 animate-fade-up"
            style={{ background: "var(--bg-surface)", borderRight: "1px solid var(--border-subtle)" }}>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile topbar */}
        <div className="md:hidden flex items-center gap-3 px-4 py-3 border-b" style={{ borderColor: "var(--border-subtle)", background: "var(--bg-surface)" }}>
          <button onClick={() => setMobileOpen(true)} className="p-1.5 rounded-lg" style={{ color: "var(--text-secondary)" }}>
            <Menu className="w-5 h-5" />
          </button>
          <span className="font-serif text-sm" style={{ color: "var(--text-primary)" }}>LibraryOS</span>
        </div>
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
