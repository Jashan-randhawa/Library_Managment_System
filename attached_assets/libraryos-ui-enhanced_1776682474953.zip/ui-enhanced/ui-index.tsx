import { cn } from "../../lib/utils";

// ─── Badge ────────────────────────────────────────────────────────────────────
type BadgeVariant = "default" | "success" | "warning" | "danger" | "info" | "neutral";
const badgeStyles: Record<BadgeVariant, { bg: string; color: string }> = {
  default:  { bg: "rgba(129,140,248,0.15)", color: "#a5b4fc" },
  success:  { bg: "rgba(52,211,153,0.12)",  color: "#6ee7b7" },
  warning:  { bg: "rgba(251,191,36,0.12)",  color: "#fcd34d" },
  danger:   { bg: "rgba(248,113,113,0.15)", color: "#fca5a5" },
  info:     { bg: "rgba(56,189,248,0.12)",  color: "#7dd3fc" },
  neutral:  { bg: "rgba(255,255,255,0.07)", color: "#8b97a8" },
};

export function Badge({ children, variant = "default", className }: { children: React.ReactNode; variant?: BadgeVariant; className?: string }) {
  const s = badgeStyles[variant];
  return (
    <span className={cn("inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium", className)}
      style={{ background: s.bg, color: s.color, border: `1px solid ${s.color}22` }}>
      {children}
    </span>
  );
}

// ─── Card ─────────────────────────────────────────────────────────────────────
export function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("rounded-2xl transition-all duration-200", className)}
      style={{ background: "var(--bg-surface)", border: "1px solid var(--border-subtle)" }}>
      {children}
    </div>
  );
}

// ─── Button ───────────────────────────────────────────────────────────────────
type ButtonVariant = "primary" | "secondary" | "danger" | "ghost";

export function Button({ children, variant = "primary", className, onClick, disabled, type = "button" }: {
  children: React.ReactNode; variant?: ButtonVariant; className?: string;
  onClick?: () => void; disabled?: boolean; type?: "button" | "submit";
}) {
  const base = "inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed";
  if (variant === "primary") return (
    <button type={type} disabled={disabled} onClick={onClick} className={cn(base, "btn-amber", className)}>
      {children}
    </button>
  );
  if (variant === "secondary") return (
    <button type={type} disabled={disabled} onClick={onClick} className={cn(base, className)}
      style={{ background: "rgba(255,255,255,0.06)", color: "var(--text-secondary)", border: "1px solid var(--border-mid)" }}>
      {children}
    </button>
  );
  if (variant === "danger") return (
    <button type={type} disabled={disabled} onClick={onClick} className={cn(base, className)}
      style={{ background: "rgba(248,113,113,0.15)", color: "#f87171", border: "1px solid rgba(248,113,113,0.2)" }}>
      {children}
    </button>
  );
  return (
    <button type={type} disabled={disabled} onClick={onClick} className={cn(base, "hover:bg-white/5", className)}
      style={{ color: "var(--text-secondary)" }}>
      {children}
    </button>
  );
}

// ─── Input ────────────────────────────────────────────────────────────────────
export function Input({ label, placeholder, value, onChange, type = "text", className }: {
  label?: string; placeholder?: string; value: string;
  onChange: (v: string) => void; type?: string; className?: string;
}) {
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      {label && <label className="text-xs font-medium" style={{ color: "var(--text-secondary)" }}>{label}</label>}
      <input type={type} placeholder={placeholder} value={value} onChange={(e) => onChange(e.target.value)}
        className="px-3 py-2.5 rounded-xl text-sm transition-all duration-200 outline-none"
        style={{
          background: "var(--bg-elevated)", color: "var(--text-primary)",
          border: "1px solid var(--border-mid)",
        }}
        onFocus={e => { e.target.style.border = "1px solid rgba(245,158,11,0.5)"; e.target.style.boxShadow = "0 0 0 3px rgba(245,158,11,0.08)"; }}
        onBlur={e => { e.target.style.border = "1px solid var(--border-mid)"; e.target.style.boxShadow = "none"; }}
      />
    </div>
  );
}

// ─── Select ───────────────────────────────────────────────────────────────────
export function Select({ label, value, onChange, options, className }: {
  label?: string; value: string; onChange: (v: string) => void;
  options: { label: string; value: string }[]; className?: string;
}) {
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      {label && <label className="text-xs font-medium" style={{ color: "var(--text-secondary)" }}>{label}</label>}
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="px-3 py-2.5 rounded-xl text-sm transition-all duration-200 outline-none cursor-pointer"
        style={{
          background: "var(--bg-elevated)", color: "var(--text-primary)",
          border: "1px solid var(--border-mid)",
        }}>
        {options.map((o) => <option key={o.value} value={o.value} style={{ background: "#1c2230" }}>{o.label}</option>)}
      </select>
    </div>
  );
}

// ─── Table ────────────────────────────────────────────────────────────────────
export function Table({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("w-full overflow-x-auto", className)}>
      <table className="w-full text-sm text-left">{children}</table>
    </div>
  );
}

export function Th({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <th className={cn("px-4 py-3 text-xs font-semibold uppercase tracking-wider", className)}
      style={{ color: "var(--text-muted)", borderBottom: "1px solid var(--border-subtle)" }}>
      {children}
    </th>
  );
}

export function Td({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <td className={cn("px-4 py-3.5", className)}
      style={{ color: "var(--text-secondary)", borderBottom: "1px solid rgba(255,255,255,0.03)" }}>
      {children}
    </td>
  );
}

// ─── PageHeader ───────────────────────────────────────────────────────────────
export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between mb-8">
      <div>
        <h1 className="font-serif text-3xl leading-tight gradient-text-amber">{title}</h1>
        {subtitle && <p className="text-sm mt-1" style={{ color: "var(--text-muted)" }}>{subtitle}</p>}
      </div>
      {action && <div>{action}</div>}
    </div>
  );
}

// ─── StatCard ─────────────────────────────────────────────────────────────────
const statBorderClass: Record<string, string> = {
  indigo: "stat-border-indigo", emerald: "stat-border-emerald",
  amber: "stat-border-amber", red: "stat-border-red", sky: "stat-border-sky",
};
const statIconStyle: Record<string, { bg: string; color: string }> = {
  indigo:  { bg: "rgba(129,140,248,0.12)", color: "#818cf8" },
  emerald: { bg: "rgba(52,211,153,0.12)",  color: "#34d399" },
  amber:   { bg: "rgba(245,158,11,0.12)",  color: "#f59e0b" },
  red:     { bg: "rgba(248,113,113,0.12)", color: "#f87171" },
  sky:     { bg: "rgba(56,189,248,0.12)",  color: "#38bdf8" },
};

export function StatCard({ title, value, icon: Icon, trend, color = "indigo" }: {
  title: string; value: string | number; icon: React.ElementType;
  trend?: { value: string; positive: boolean }; color?: "indigo" | "emerald" | "amber" | "red" | "sky";
}) {
  const ic = statIconStyle[color];
  return (
    <div className={cn("rounded-2xl p-5 animate-fade-up transition-all duration-200 hover:-translate-y-0.5", statBorderClass[color])}
      style={{ background: "var(--bg-surface)", border: "1px solid var(--border-subtle)", borderTop: undefined }}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: "var(--text-muted)" }}>{title}</p>
          <p className="text-3xl font-bold" style={{ color: "var(--text-primary)" }}>{value}</p>
          {trend && (
            <p className="text-xs mt-1.5 font-medium" style={{ color: trend.positive ? "#34d399" : "#f87171" }}>
              {trend.positive ? "↑" : "↓"} {trend.value}
            </p>
          )}
        </div>
        <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: ic.bg }}>
          <Icon className="w-5 h-5" style={{ color: ic.color }} />
        </div>
      </div>
    </div>
  );
}

// ─── Empty ────────────────────────────────────────────────────────────────────
export function Empty({ message }: { message: string }) {
  return (
    <div className="py-20 text-center">
      <div className="w-14 h-14 rounded-2xl mx-auto mb-4 flex items-center justify-center"
        style={{ background: "rgba(255,255,255,0.04)", border: "1px solid var(--border-subtle)" }}>
        <span className="text-2xl">📚</span>
      </div>
      <p className="text-sm font-medium" style={{ color: "var(--text-muted)" }}>{message}</p>
      <p className="text-xs mt-1" style={{ color: "var(--text-muted)", opacity: 0.6 }}>Nothing to display here yet</p>
    </div>
  );
}

// ─── Modal ────────────────────────────────────────────────────────────────────
export function Modal({ open, onClose, title, children }: {
  open: boolean; onClose: () => void; title: string; children: React.ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center animate-fade-in">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={onClose} />
      <div className="relative w-full max-w-md mx-4 p-6 rounded-2xl animate-fade-up glass-elevated"
        style={{ border: "1px solid var(--border-mid)" }}>
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-serif text-xl" style={{ color: "var(--text-primary)" }}>{title}</h2>
          <button onClick={onClose} className="w-7 h-7 rounded-lg flex items-center justify-center text-lg transition-colors"
            style={{ color: "var(--text-muted)", background: "rgba(255,255,255,0.05)" }}
            onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.1)")}
            onMouseLeave={e => (e.currentTarget.style.background = "rgba(255,255,255,0.05)")}>
            ×
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ─── SearchInput ──────────────────────────────────────────────────────────────
export function SearchInput({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div className="relative flex-1 min-w-48">
      <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: "var(--text-muted)" }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
      </svg>
      <input placeholder={placeholder || "Search..."} value={value} onChange={(e) => onChange(e.target.value)}
        className="w-full pl-9 pr-3 py-2.5 rounded-xl text-sm outline-none transition-all"
        style={{ background: "var(--bg-elevated)", color: "var(--text-primary)", border: "1px solid var(--border-mid)" }}
        onFocus={e => { e.target.style.border = "1px solid rgba(245,158,11,0.4)"; e.target.style.boxShadow = "0 0 0 3px rgba(245,158,11,0.07)"; }}
        onBlur={e => { e.target.style.border = "1px solid var(--border-mid)"; e.target.style.boxShadow = "none"; }}
      />
    </div>
  );
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────
export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("rounded-xl shimmer", className)} style={{ background: "rgba(255,255,255,0.05)" }} />;
}

// ─── FilterBar ────────────────────────────────────────────────────────────────
export function FilterBar({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex gap-3 flex-wrap p-4 rounded-2xl mb-5"
      style={{ background: "var(--bg-surface)", border: "1px solid var(--border-subtle)" }}>
      {children}
    </div>
  );
}
