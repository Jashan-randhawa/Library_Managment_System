import { useState, useEffect, useCallback } from "react";
import { IndianRupee } from "lucide-react";
import { PageHeader, Card, Badge, Button, Select, Table, Th, Td, Empty, FilterBar, SearchInput, Skeleton } from "../components/ui";
import { finesApi } from "../lib/api";
import { formatDate, formatCurrency } from "../lib/utils";

interface Fine { _id: string; memberName: string; bookTitle: string; reason: string; amount: number; issuedDate: string; paidDate?: string; status: string; }
const statusOptions = [{ value: "", label: "All Status" },{ value: "unpaid", label: "Unpaid" },{ value: "paid", label: "Paid" },{ value: "waived", label: "Waived" }];
const statusBadge: Record<string, "danger"|"success"|"neutral"> = { unpaid: "danger", paid: "success", waived: "neutral" };

export default function Fines() {
  const [fines, setFines] = useState<Fine[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  const fetchFines = useCallback(async () => {
    setLoading(true);
    try { const data = await finesApi.getAll({ search, status }); setFines(data as Fine[]); }
    catch (e) { console.error(e); } finally { setLoading(false); }
  }, [search, status]);

  useEffect(() => { fetchFines(); }, [fetchFines]);

  const handlePay = async (id: string) => { try { await finesApi.pay(id); fetchFines(); } catch (e) { console.error(e); } };
  const handleWaive = async (id: string) => { try { await finesApi.waive(id); fetchFines(); } catch (e) { console.error(e); } };

  const totalUnpaid = fines.filter(f => f.status === "unpaid").reduce((s, f) => s + f.amount, 0);
  const totalCollected = fines.filter(f => f.status === "paid").reduce((s, f) => s + f.amount, 0);
  const waivedCount = fines.filter(f => f.status === "waived").length;

  return (
    <div className="p-6 md:p-8 animate-fade-up">
      <PageHeader title="Fines" subtitle="Manage overdue and damage fines" />

      <div className="grid grid-cols-3 gap-4 mb-5">
        {[
          { label: "Unpaid Total", value: formatCurrency(totalUnpaid), color: "#f87171", bg: "rgba(248,113,113,0.1)" },
          { label: `${fines.filter(f => f.status === "paid").length} fines collected`, value: formatCurrency(totalCollected), color: "#34d399", bg: "rgba(52,211,153,0.1)" },
          { label: "Fines Waived", value: String(waivedCount), color: "#8b97a8", bg: "rgba(255,255,255,0.05)" },
        ].map(({ label, value, color, bg }) => (
          <Card key={label} className="p-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: bg }}>
                <IndianRupee className="w-4 h-4" style={{ color }} />
              </div>
              <div>
                <p className="text-2xl font-bold" style={{ color }}>{value}</p>
                <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>{label}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <FilterBar>
        <SearchInput value={search} onChange={setSearch} placeholder="Search by member or book..." />
        <Select value={status} onChange={setStatus} options={statusOptions} />
      </FilterBar>

      <Card>
        {loading ? (
          <div className="p-4 space-y-3">{[...Array(6)].map((_, i) => <Skeleton key={i} className="h-14" />)}</div>
        ) : (
          <Table>
            <thead><tr><Th>Member</Th><Th>Book</Th><Th>Reason</Th><Th>Amount</Th><Th>Issued</Th><Th>Paid On</Th><Th>Status</Th><Th>Actions</Th></tr></thead>
            <tbody>
              {fines.length === 0 ? <tr><td colSpan={8}><Empty message="No fines found" /></td></tr> :
                fines.map((fine) => (
                  <tr key={fine._id} className="table-row-hover" style={fine.status === "unpaid" ? { background: "rgba(248,113,113,0.02)" } : {}}>
                    <Td>
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 text-xs font-bold"
                          style={{ background: "rgba(248,113,113,0.15)", color: "#f87171" }}>
                          {fine.memberName[0]}
                        </div>
                        <span className="font-medium text-sm" style={{ color: "var(--text-primary)" }}>{fine.memberName}</span>
                      </div>
                    </Td>
                    <Td><p className="text-xs max-w-36 truncate" style={{ color: "var(--text-secondary)" }}>{fine.bookTitle}</p></Td>
                    <Td><span className="text-xs" style={{ color: "var(--text-muted)" }}>{fine.reason}</span></Td>
                    <Td>
                      <span className="font-bold text-sm" style={{ color: fine.status === "unpaid" ? "#f87171" : "var(--text-muted)" }}>
                        {formatCurrency(fine.amount)}
                      </span>
                    </Td>
                    <Td><span className="text-xs whitespace-nowrap" style={{ color: "var(--text-muted)" }}>{formatDate(fine.issuedDate)}</span></Td>
                    <Td><span className="text-xs whitespace-nowrap" style={{ color: "var(--text-muted)" }}>{fine.paidDate ? formatDate(fine.paidDate) : "—"}</span></Td>
                    <Td><Badge variant={statusBadge[fine.status]}>{fine.status}</Badge></Td>
                    <Td>{fine.status === "unpaid" && (
                      <div className="flex gap-1">
                        <Button variant="ghost" className="text-xs px-2 py-1" onClick={() => handlePay(fine._id)}
                          style={{ color: "#34d399" }}>Pay</Button>
                        <Button variant="ghost" className="text-xs px-2 py-1" onClick={() => handleWaive(fine._id)}>Waive</Button>
                      </div>
                    )}</Td>
                  </tr>
                ))}
            </tbody>
          </Table>
        )}
      </Card>
    </div>
  );
}
