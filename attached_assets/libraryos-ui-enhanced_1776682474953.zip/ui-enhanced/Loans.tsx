import { useState, useEffect, useCallback } from "react";
import { BookMarked, CheckCircle, AlertTriangle } from "lucide-react";
import { PageHeader, Card, Badge, Button, Select, Table, Th, Td, Empty, FilterBar, SearchInput, Skeleton } from "../components/ui";
import { loansApi } from "../lib/api";
import { formatDate, getDaysOverdue } from "../lib/utils";

interface Loan { _id: string; bookTitle: string; memberName: string; issueDate: string; dueDate: string; returnDate?: string; status: string; }
const statusOptions = [{ value: "", label: "All Status" },{ value: "active", label: "Active" },{ value: "overdue", label: "Overdue" },{ value: "returned", label: "Returned" }];
const statusBadge: Record<string, "info"|"danger"|"success"> = { active: "info", overdue: "danger", returned: "success" };

export default function Loans() {
  const [loans, setLoans] = useState<Loan[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  const fetchLoans = useCallback(async () => {
    setLoading(true);
    try { const data = await loansApi.getAll({ search, status }); setLoans(data as Loan[]); }
    catch (e) { console.error(e); } finally { setLoading(false); }
  }, [search, status]);

  useEffect(() => { fetchLoans(); }, [fetchLoans]);

  const handleReturn = async (id: string) => {
    try { await loansApi.returnBook(id); fetchLoans(); } catch (e) { console.error(e); }
  };

  const active = loans.filter(l => l.status === "active").length;
  const overdue = loans.filter(l => l.status === "overdue").length;
  const returned = loans.filter(l => l.status === "returned").length;

  return (
    <div className="p-6 md:p-8 animate-fade-up">
      <PageHeader title="Loans" subtitle={`${loans.length} total loans tracked`} />

      <div className="grid grid-cols-3 gap-4 mb-5">
        {[{ label: "Active Loans", value: active, icon: BookMarked, color: "#38bdf8", bg: "rgba(56,189,248,0.1)" },
          { label: "Overdue", value: overdue, icon: AlertTriangle, color: "#f87171", bg: "rgba(248,113,113,0.1)" },
          { label: "Returned", value: returned, icon: CheckCircle, color: "#34d399", bg: "rgba(52,211,153,0.1)" }]
          .map(({ label, value, icon: Icon, color, bg }) => (
          <Card key={label} className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: bg }}>
              <Icon className="w-4 h-4" style={{ color }} />
            </div>
            <div>
              <p className="text-2xl font-bold" style={{ color: "var(--text-primary)" }}>{value}</p>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>{label}</p>
            </div>
          </Card>
        ))}
      </div>

      <FilterBar>
        <SearchInput value={search} onChange={setSearch} placeholder="Search by book or member..." />
        <Select value={status} onChange={setStatus} options={statusOptions} />
      </FilterBar>

      <Card>
        {loading ? (
          <div className="p-4 space-y-3">{[...Array(6)].map((_, i) => <Skeleton key={i} className="h-14" />)}</div>
        ) : (
          <Table>
            <thead><tr><Th>Book</Th><Th>Member</Th><Th>Issue Date</Th><Th>Due Date</Th><Th>Return Date</Th><Th>Status</Th><Th>Action</Th></tr></thead>
            <tbody>
              {loans.length === 0 ? <tr><td colSpan={7}><Empty message="No loans found" /></td></tr> :
                loans.map((loan) => {
                  const daysOverdue = getDaysOverdue(loan.dueDate);
                  return (
                    <tr key={loan._id} className="table-row-hover" style={loan.status === "overdue" ? { background: "rgba(248,113,113,0.03)" } : {}}>
                      <Td>
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-9 rounded-md flex items-center justify-center flex-shrink-0"
                            style={{ background: "rgba(129,140,248,0.15)" }}>
                            <BookMarked className="w-3 h-3" style={{ color: "#818cf8" }} />
                          </div>
                          <p className="font-medium text-sm" style={{ color: "var(--text-primary)" }}>{loan.bookTitle}</p>
                        </div>
                      </Td>
                      <Td>
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold"
                            style={{ background: "rgba(245,158,11,0.15)", color: "#f59e0b" }}>
                            {loan.memberName[0]}
                          </div>
                          <span className="text-sm" style={{ color: "var(--text-secondary)" }}>{loan.memberName}</span>
                        </div>
                      </Td>
                      <Td><span className="text-xs whitespace-nowrap" style={{ color: "var(--text-muted)" }}>{formatDate(loan.issueDate)}</span></Td>
                      <Td>
                        <span className="text-xs whitespace-nowrap font-medium" style={{ color: loan.status === "overdue" ? "#f87171" : "var(--text-muted)" }}>
                          {formatDate(loan.dueDate)}
                        </span>
                      </Td>
                      <Td><span className="text-xs whitespace-nowrap" style={{ color: "var(--text-muted)" }}>{loan.returnDate ? formatDate(loan.returnDate) : "—"}</span></Td>
                      <Td>
                        <div className="flex flex-col gap-1">
                          <Badge variant={statusBadge[loan.status]}>{loan.status}</Badge>
                          {loan.status === "overdue" && daysOverdue > 0 && (
                            <span className="text-xs font-medium" style={{ color: "#f87171" }}>{daysOverdue}d late</span>
                          )}
                        </div>
                      </Td>
                      <Td>{loan.status !== "returned" && (
                        <Button variant="ghost" className="text-xs px-2 py-1" onClick={() => handleReturn(loan._id)}>
                          Mark Returned
                        </Button>
                      )}</Td>
                    </tr>
                  );
                })}
            </tbody>
          </Table>
        )}
      </Card>
    </div>
  );
}
