import { useState, useEffect, useCallback } from "react";
import { CalendarCheck } from "lucide-react";
import { PageHeader, Card, Badge, Button, Select, Table, Th, Td, Empty, FilterBar, SearchInput, Skeleton } from "../components/ui";
import { reservationsApi } from "../lib/api";
import { formatDate } from "../lib/utils";

interface Reservation { _id: string; bookTitle: string; memberName: string; reservationDate: string; expiryDate: string; status: string; queuePosition: number; }
const statusOptions = [{ value: "", label: "All Status" },{ value: "pending", label: "Pending" },{ value: "fulfilled", label: "Fulfilled" },{ value: "cancelled", label: "Cancelled" },{ value: "expired", label: "Expired" }];
const statusBadge: Record<string, "warning"|"success"|"neutral"|"danger"> = { pending: "warning", fulfilled: "success", cancelled: "neutral", expired: "danger" };

export default function Reservations() {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  const fetchReservations = useCallback(async () => {
    setLoading(true);
    try { const data = await reservationsApi.getAll({ search, status }); setReservations(data as Reservation[]); }
    catch (e) { console.error(e); } finally { setLoading(false); }
  }, [search, status]);

  useEffect(() => { fetchReservations(); }, [fetchReservations]);

  const handleFulfill = async (id: string) => { try { await reservationsApi.fulfill(id); fetchReservations(); } catch (e) { console.error(e); } };
  const handleCancel = async (id: string) => { try { await reservationsApi.cancel(id); fetchReservations(); } catch (e) { console.error(e); } };

  const pending = reservations.filter(r => r.status === "pending").length;

  return (
    <div className="p-6 md:p-8 animate-fade-up">
      <PageHeader title="Reservations" subtitle={`${reservations.length} total reservations`} />

      <div className="grid grid-cols-4 gap-4 mb-5">
        {[
          { label: "Pending", key: "pending", color: "#fbbf24", bg: "rgba(251,191,36,0.1)" },
          { label: "Fulfilled", key: "fulfilled", color: "#34d399", bg: "rgba(52,211,153,0.1)" },
          { label: "Cancelled", key: "cancelled", color: "#8b97a8", bg: "rgba(255,255,255,0.05)" },
          { label: "Expired", key: "expired", color: "#f87171", bg: "rgba(248,113,113,0.1)" },
        ].map(({ label, key, color, bg }) => (
          <Card key={key} className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: bg }}>
              <CalendarCheck className="w-4 h-4" style={{ color }} />
            </div>
            <div>
              <p className="text-xl font-bold" style={{ color: "var(--text-primary)" }}>{reservations.filter(r => r.status === key).length}</p>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>{label}</p>
            </div>
          </Card>
        ))}
      </div>

      <FilterBar>
        <SearchInput value={search} onChange={setSearch} placeholder="Search by book or member..." />
        <Select value={status} onChange={setStatus} options={statusOptions} />
      </FilterBar>

      <Card>
        {loading ? (
          <div className="p-4 space-y-3">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-14" />)}</div>
        ) : (
          <Table>
            <thead><tr><Th>Book</Th><Th>Member</Th><Th>Reserved On</Th><Th>Expires</Th><Th>Queue</Th><Th>Status</Th><Th>Actions</Th></tr></thead>
            <tbody>
              {reservations.length === 0 ? <tr><td colSpan={7}><Empty message="No reservations found" /></td></tr> :
                reservations.map((r) => (
                  <tr key={r._id} className="table-row-hover">
                    <Td>
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-9 rounded-md flex items-center justify-center flex-shrink-0"
                          style={{ background: "rgba(251,191,36,0.12)" }}>
                          <CalendarCheck className="w-3 h-3" style={{ color: "#fbbf24" }} />
                        </div>
                        <p className="font-medium text-sm" style={{ color: "var(--text-primary)" }}>{r.bookTitle}</p>
                      </div>
                    </Td>
                    <Td>
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                          style={{ background: "rgba(129,140,248,0.15)", color: "#818cf8" }}>
                          {r.memberName[0]}
                        </div>
                        <span className="text-sm" style={{ color: "var(--text-secondary)" }}>{r.memberName}</span>
                      </div>
                    </Td>
                    <Td><span className="text-xs whitespace-nowrap" style={{ color: "var(--text-muted)" }}>{formatDate(r.reservationDate)}</span></Td>
                    <Td><span className="text-xs whitespace-nowrap" style={{ color: "var(--text-muted)" }}>{formatDate(r.expiryDate)}</span></Td>
                    <Td>
                      <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                        style={{ background: "rgba(245,158,11,0.15)", color: "#f59e0b" }}>
                        #{r.queuePosition}
                      </span>
                    </Td>
                    <Td><Badge variant={statusBadge[r.status]}>{r.status}</Badge></Td>
                    <Td>{r.status === "pending" && (
                      <div className="flex gap-1">
                        <Button variant="ghost" className="text-xs px-2 py-1" onClick={() => handleFulfill(r._id)}
                          style={{ color: "#34d399" }}>Fulfill</Button>
                        <Button variant="ghost" className="text-xs px-2 py-1" onClick={() => handleCancel(r._id)}>Cancel</Button>
                      </div>
                    )}</Td>
                  </tr>
                ))}
            </tbody>
          </Table>
        )}
      </Card>
    </div>
  );
}
