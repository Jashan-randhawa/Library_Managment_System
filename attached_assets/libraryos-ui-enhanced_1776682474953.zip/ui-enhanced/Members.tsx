import { useState, useEffect, useCallback } from "react";
import { Plus, User } from "lucide-react";
import { PageHeader, Card, Badge, Button, Input, Select, Table, Th, Td, Modal, Empty, FilterBar, SearchInput, Skeleton } from "../components/ui";
import { membersApi } from "../lib/api";
import { formatDate, formatCurrency } from "../lib/utils";

interface Member { _id: string; name: string; email: string; phone: string; membershipType: string; joinDate: string; status: string; loansCount: number; finesOwed: number; }

const statusOptions = [{ value: "", label: "All Status" },{ value: "active", label: "Active" },{ value: "suspended", label: "Suspended" },{ value: "expired", label: "Expired" }];
const membershipOptions = [{ value: "", label: "All Types" },{ value: "standard", label: "Standard" },{ value: "premium", label: "Premium" },{ value: "student", label: "Student" }];
const membershipBadge: Record<string, "default"|"success"|"neutral"> = { premium: "success", standard: "default", student: "neutral" };
const statusBadge: Record<string, "success"|"danger"|"warning"> = { active: "success", suspended: "danger", expired: "warning" };

const avatarColors = ["#6366f1","#10b981","#f59e0b","#ec4899","#0ea5e9","#8b5cf6","#14b8a6","#f97316"];

export default function Members() {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [membership, setMembership] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [newMember, setNewMember] = useState({ name: "", email: "", phone: "", membershipType: "standard" });

  const fetchMembers = useCallback(async () => {
    setLoading(true);
    try { const data = await membersApi.getAll({ search, status, membershipType: membership }); setMembers(data as Member[]); }
    catch (e) { console.error(e); } finally { setLoading(false); }
  }, [search, status, membership]);

  useEffect(() => { fetchMembers(); }, [fetchMembers]);

  const handleAdd = async () => {
    if (!newMember.name || !newMember.email) return;
    setSaving(true); setError("");
    try {
      await membersApi.create(newMember);
      setAddOpen(false);
      setNewMember({ name: "", email: "", phone: "", membershipType: "standard" });
      fetchMembers();
    } catch (e: unknown) { setError(e instanceof Error ? e.message : "Failed to add member"); }
    finally { setSaving(false); }
  };

  return (
    <div className="p-6 md:p-8 animate-fade-up">
      <PageHeader title="Members" subtitle={`${members.length} members registered`}
        action={<Button onClick={() => setAddOpen(true)}><Plus className="w-4 h-4" /> Add Member</Button>} />

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-4 mb-5">
        {[{ label: "Active", key: "active", color: "#34d399", bg: "rgba(52,211,153,0.1)" },
          { label: "Suspended", key: "suspended", color: "#f87171", bg: "rgba(248,113,113,0.1)" },
          { label: "Expired", key: "expired", color: "#fbbf24", bg: "rgba(251,191,36,0.1)" }].map(({ label, key, color, bg }) => (
          <Card key={key} className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: bg }}>
              <User className="w-4 h-4" style={{ color }} />
            </div>
            <div>
              <p className="text-2xl font-bold" style={{ color: "var(--text-primary)" }}>{members.filter(m => m.status === key).length}</p>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>{label} Members</p>
            </div>
          </Card>
        ))}
      </div>

      <FilterBar>
        <SearchInput value={search} onChange={setSearch} placeholder="Search by name or email..." />
        <Select value={status} onChange={setStatus} options={statusOptions} />
        <Select value={membership} onChange={setMembership} options={membershipOptions} />
      </FilterBar>

      <Card>
        {loading ? (
          <div className="p-4 space-y-3">{[...Array(6)].map((_, i) => <Skeleton key={i} className="h-14" />)}</div>
        ) : (
          <Table>
            <thead><tr><Th>Member</Th><Th>Phone</Th><Th>Membership</Th><Th>Joined</Th><Th>Loans</Th><Th>Fines Owed</Th><Th>Status</Th></tr></thead>
            <tbody>
              {members.length === 0 ? <tr><td colSpan={7}><Empty message="No members found" /></td></tr> :
                members.map((m, i) => {
                  const initials = m.name.split(" ").map(n => n[0]).join("").slice(0,2).toUpperCase();
                  const color = avatarColors[i % avatarColors.length];
                  return (
                    <tr key={m._id} className="table-row-hover">
                      <Td>
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 text-xs font-bold text-white"
                            style={{ background: `linear-gradient(135deg, ${color}, ${color}aa)`, boxShadow: `0 4px 10px ${color}33` }}>
                            {initials}
                          </div>
                          <div>
                            <p className="font-medium text-sm" style={{ color: "var(--text-primary)" }}>{m.name}</p>
                            <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>{m.email}</p>
                          </div>
                        </div>
                      </Td>
                      <Td><span className="text-xs font-mono-dm" style={{ color: "var(--text-muted)" }}>{m.phone}</span></Td>
                      <Td><Badge variant={membershipBadge[m.membershipType]}>{m.membershipType}</Badge></Td>
                      <Td><span className="text-xs" style={{ color: "var(--text-muted)" }}>{formatDate(m.joinDate)}</span></Td>
                      <Td><span className="font-medium" style={{ color: "var(--text-secondary)" }}>{m.loansCount}</span></Td>
                      <Td>{m.finesOwed > 0
                        ? <span className="font-semibold text-sm" style={{ color: "#f87171" }}>{formatCurrency(m.finesOwed)}</span>
                        : <span style={{ color: "var(--text-muted)" }}>—</span>}
                      </Td>
                      <Td><Badge variant={statusBadge[m.status]}>{m.status}</Badge></Td>
                    </tr>
                  );
                })}
            </tbody>
          </Table>
        )}
      </Card>

      <Modal open={addOpen} onClose={() => { setAddOpen(false); setError(""); }} title="Add New Member">
        <div className="space-y-3">
          {error && <p className="text-xs px-3 py-2 rounded-xl" style={{ color: "#f87171", background: "rgba(248,113,113,0.1)" }}>{error}</p>}
          <Input label="Full Name *" placeholder="Ravi Kumar" value={newMember.name} onChange={(v) => setNewMember({ ...newMember, name: v })} />
          <Input label="Email *" type="email" placeholder="ravi@email.com" value={newMember.email} onChange={(v) => setNewMember({ ...newMember, email: v })} />
          <Input label="Phone" placeholder="+91-XXXXX-XXXXX" value={newMember.phone} onChange={(v) => setNewMember({ ...newMember, phone: v })} />
          <Select label="Membership Type" value={newMember.membershipType} onChange={(v) => setNewMember({ ...newMember, membershipType: v })}
            options={[{ value: "standard", label: "Standard" },{ value: "premium", label: "Premium" },{ value: "student", label: "Student" }]} />
          <div className="flex gap-2 pt-2">
            <Button variant="secondary" onClick={() => setAddOpen(false)} className="flex-1">Cancel</Button>
            <Button onClick={handleAdd} disabled={saving} className="flex-1">{saving ? "Adding..." : "Add Member"}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
