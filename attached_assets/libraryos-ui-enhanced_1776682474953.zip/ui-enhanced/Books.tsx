import { useState, useEffect, useCallback } from "react";
import { Plus, BookOpen } from "lucide-react";
import { PageHeader, Card, Badge, Button, Input, Select, Table, Th, Td, Modal, Empty, FilterBar, SearchInput, Skeleton } from "../components/ui";
import { booksApi } from "../lib/api";

interface Book { _id: string; title: string; author: string; isbn: string; genre: string; publishedYear: number; totalCopies: number; availableCopies: number; coverColor?: string; }

const genreOptions = [
  { value: "", label: "All Genres" },
  { value: "Fiction", label: "Fiction" }, { value: "Fantasy", label: "Fantasy" },
  { value: "Dystopian", label: "Dystopian" }, { value: "Historical", label: "Historical" },
  { value: "Romance", label: "Romance" }, { value: "Adventure", label: "Adventure" },
  { value: "Autobiography", label: "Autobiography" }, { value: "Historical Fiction", label: "Historical Fiction" },
];

const coverColors = ["#6366f1","#10b981","#f59e0b","#ec4899","#ef4444","#8b5cf6","#14b8a6","#0ea5e9","#f97316","#84cc16"];

function BookCover({ book }: { book: Book }) {
  return (
    <div className="w-9 h-12 rounded-lg flex items-center justify-center flex-shrink-0 relative overflow-hidden"
      style={{ background: `linear-gradient(135deg, ${book.coverColor || "#6366f1"}, ${book.coverColor || "#6366f1"}88)`, boxShadow: `0 4px 12px ${book.coverColor || "#6366f1"}33` }}>
      <BookOpen className="w-4 h-4 text-white/80" />
    </div>
  );
}

export default function Books() {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [genre, setGenre] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [newBook, setNewBook] = useState({ title: "", author: "", isbn: "", genre: "Fiction", publishedYear: "2020", totalCopies: "3" });

  const fetchBooks = useCallback(async () => {
    setLoading(true);
    try { const data = await booksApi.getAll({ search, genre }); setBooks(data as Book[]); }
    catch (e) { console.error(e); } finally { setLoading(false); }
  }, [search, genre]);

  useEffect(() => { fetchBooks(); }, [fetchBooks]);

  const handleAdd = async () => {
    if (!newBook.title || !newBook.author) return;
    setSaving(true); setError("");
    try {
      await booksApi.create({ ...newBook, publishedYear: parseInt(newBook.publishedYear), totalCopies: parseInt(newBook.totalCopies), coverColor: coverColors[Math.floor(Math.random() * coverColors.length)] });
      setAddOpen(false);
      setNewBook({ title: "", author: "", isbn: "", genre: "Fiction", publishedYear: "2020", totalCopies: "3" });
      fetchBooks();
    } catch (e: unknown) { setError(e instanceof Error ? e.message : "Failed to add book"); }
    finally { setSaving(false); }
  };

  return (
    <div className="p-6 md:p-8 animate-fade-up">
      <PageHeader title="Books" subtitle={`${books.length} books in catalog`}
        action={<Button onClick={() => setAddOpen(true)}><Plus className="w-4 h-4" /> Add Book</Button>} />

      <FilterBar>
        <SearchInput value={search} onChange={setSearch} placeholder="Search by title or author..." />
        <Select value={genre} onChange={setGenre} options={genreOptions} className="min-w-36" />
      </FilterBar>

      <Card>
        {loading ? (
          <div className="p-4 space-y-3">
            {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-14" />)}
          </div>
        ) : (
          <Table>
            <thead><tr>
              <Th>Book</Th><Th>ISBN</Th><Th>Genre</Th><Th>Year</Th><Th>Copies</Th><Th>Available</Th><Th>Status</Th>
            </tr></thead>
            <tbody>
              {books.length === 0 ? <tr><td colSpan={7}><Empty message="No books found" /></td></tr> :
                books.map((book) => (
                  <tr key={book._id} className="table-row-hover">
                    <Td><div className="flex items-center gap-3"><BookCover book={book} /><div>
                      <p className="font-medium text-sm" style={{ color: "var(--text-primary)" }}>{book.title}</p>
                      <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>{book.author}</p>
                    </div></div></Td>
                    <Td><span className="font-mono-dm text-xs px-2 py-1 rounded-lg" style={{ background: "rgba(255,255,255,0.05)", color: "var(--text-muted)" }}>{book.isbn}</span></Td>
                    <Td><Badge variant="neutral">{book.genre}</Badge></Td>
                    <Td><span style={{ color: "var(--text-muted)" }}>{book.publishedYear}</span></Td>
                    <Td><span style={{ color: "var(--text-secondary)" }}>{book.totalCopies}</span></Td>
                    <Td><span style={{ color: "var(--text-secondary)" }}>{book.availableCopies}</span></Td>
                    <Td><Badge variant={book.availableCopies === 0 ? "danger" : book.availableCopies <= 1 ? "warning" : "success"}>
                      {book.availableCopies === 0 ? "Out of Stock" : book.availableCopies <= 1 ? "Low Stock" : "Available"}
                    </Badge></Td>
                  </tr>
                ))}
            </tbody>
          </Table>
        )}
      </Card>

      <Modal open={addOpen} onClose={() => { setAddOpen(false); setError(""); }} title="Add New Book">
        <div className="space-y-3">
          {error && <p className="text-xs px-3 py-2 rounded-xl" style={{ color: "#f87171", background: "rgba(248,113,113,0.1)", border: "1px solid rgba(248,113,113,0.15)" }}>{error}</p>}
          <Input label="Title *" placeholder="Book title" value={newBook.title} onChange={(v) => setNewBook({ ...newBook, title: v })} />
          <Input label="Author *" placeholder="Author name" value={newBook.author} onChange={(v) => setNewBook({ ...newBook, author: v })} />
          <Input label="ISBN" placeholder="978-..." value={newBook.isbn} onChange={(v) => setNewBook({ ...newBook, isbn: v })} />
          <div className="grid grid-cols-2 gap-3">
            <Select label="Genre" value={newBook.genre} onChange={(v) => setNewBook({ ...newBook, genre: v })} options={genreOptions.slice(1)} />
            <Input label="Year" type="number" placeholder="Year" value={newBook.publishedYear} onChange={(v) => setNewBook({ ...newBook, publishedYear: v })} />
          </div>
          <Input label="Total Copies" type="number" value={newBook.totalCopies} onChange={(v) => setNewBook({ ...newBook, totalCopies: v })} />
          <div className="flex gap-2 pt-2">
            <Button variant="secondary" onClick={() => setAddOpen(false)} className="flex-1">Cancel</Button>
            <Button onClick={handleAdd} disabled={saving} className="flex-1">{saving ? "Adding..." : "Add Book"}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
