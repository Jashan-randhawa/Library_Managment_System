import { useState, useEffect } from "react";
import { BookOpen, Users, BookMarked, AlertCircle, TrendingUp, Clock, IndianRupee } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid, Area, AreaChart } from "recharts";
import { StatCard, Card, PageHeader, Badge, Skeleton } from "../components/ui";
import { dashboardApi } from "../lib/api";
import { formatDate, formatCurrency } from "../lib/utils";

interface Stats { totalBooks: number; totalMembers: number; activeLoans: number; overdueLoans: number; totalFines: number; newMembersThisMonth: number; pendingReservations: number; }
interface Loan { _id: string; bookTitle: string; memberName: string; dueDate: string; status: string; }
interface Book { _id: string; title: string; availableCopies: number; }
interface MonthData { month: string; loans: number; }
interface GenreData { genre: string; count: number; }

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="rounded-xl px-3 py-2" style={{ background: "#1c2230", border: "1px solid rgba(255,255,255,0.1)", boxShadow: "0 8px 32px rgba(0,0,0,0.4)" }}>
        <p className="text-xs font-medium mb-1" style={{ color: "#8b97a8" }}>{label}</p>
        <p className="text-sm font-bold" style={{ color: "#f59e0b" }}>{payload[0].value} loans</p>
      </div>
    );
  }
  return null;
};

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [recentLoans, setRecentLoans] = useState<Loan[]>([]);
  const [lowStock, setLowStock] = useState<Book[]>([]);
  const [loansByMonth, setLoansByMonth] = useState<MonthData[]>([]);
  const [genreData, setGenreData] = useState<GenreData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      dashboardApi.getStats(),
      dashboardApi.getRecentLoans(),
      dashboardApi.getLowStock(),
      dashboardApi.getLoansByMonth(),
      dashboardApi.getLoansByGenre(),
    ]).then(([s, loans, stock, byMonth, byGenre]) => {
      setStats(s as Stats);
      setRecentLoans(loans as Loan[]);
      setLowStock(stock as Book[]);
      setLoansByMonth(byMonth as MonthData[]);
      setGenreData(byGenre as GenreData[]);
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="p-8 space-y-6">
      <Skeleton className="h-10 w-56" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-28" />)}
      </div>
      <div className="grid grid-cols-3 gap-6">
        <Skeleton className="col-span-2 h-64" />
        <Skeleton className="h-64" />
      </div>
    </div>
  );

  return (
    <div className="p-6 md:p-8 animate-fade-up">
      <PageHeader
        title="Dashboard"
        subtitle={`Overview · ${new Date().toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}`}
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="Total Books" value={stats?.totalBooks ?? 0} icon={BookOpen} color="indigo" trend={{ value: "in catalog", positive: true }} />
        <StatCard title="Members" value={stats?.totalMembers ?? 0} icon={Users} color="emerald" trend={{ value: `${stats?.newMembersThisMonth ?? 0} new this month`, positive: true }} />
        <StatCard title="Active Loans" value={stats?.activeLoans ?? 0} icon={BookMarked} color="sky" />
        <StatCard title="Overdue" value={stats?.overdueLoans ?? 0} icon={AlertCircle} color="red" trend={{ value: "needs attention", positive: false }} />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-5">
        {/* Area chart */}
        <Card className="lg:col-span-2 p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <p className="font-semibold text-sm" style={{ color: "var(--text-primary)" }}>Loans Over Time</p>
              <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>Last 6 months activity</p>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg" style={{ background: "rgba(245,158,11,0.1)" }}>
              <TrendingUp className="w-3.5 h-3.5" style={{ color: "#f59e0b" }} />
              <span className="text-xs font-medium" style={{ color: "#f59e0b" }}>Trending</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={190}>
            <AreaChart data={loansByMonth}>
              <defs>
                <linearGradient id="loanGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#4a5568" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#4a5568" }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="loans" stroke="#f59e0b" strokeWidth={2.5} fill="url(#loanGrad)" dot={{ fill: "#f59e0b", strokeWidth: 0, r: 4 }} activeDot={{ r: 6, fill: "#fcd34d" }} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        {/* Bar chart */}
        <Card className="p-5">
          <p className="font-semibold text-sm mb-1" style={{ color: "var(--text-primary)" }}>By Genre</p>
          <p className="text-xs mb-5" style={{ color: "var(--text-muted)" }}>Loan distribution</p>
          <ResponsiveContainer width="100%" height={190}>
            <BarChart data={genreData} layout="vertical" barSize={8}>
              <defs>
                <linearGradient id="barGrad" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#818cf8" />
                  <stop offset="100%" stopColor="#c4b5fd" />
                </linearGradient>
              </defs>
              <XAxis type="number" hide />
              <YAxis dataKey="genre" type="category" tick={{ fontSize: 10, fill: "#4a5568" }} axisLine={false} tickLine={false} width={65} />
              <Tooltip contentStyle={{ background: "#1c2230", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "10px", fontSize: 12, color: "#f0f4f8" }} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
              <Bar dataKey="count" fill="url(#barGrad)" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Recent loans */}
        <Card className="lg:col-span-2 p-5">
          <div className="flex items-center justify-between mb-5">
            <p className="font-semibold text-sm" style={{ color: "var(--text-primary)" }}>Recent Loans</p>
            <Clock className="w-4 h-4" style={{ color: "var(--text-muted)" }} />
          </div>
          <div className="space-y-1">
            {recentLoans.slice(0, 5).map((loan, i) => (
              <div key={loan._id} className="flex items-center justify-between px-3 py-2.5 rounded-xl table-row-hover"
                style={{ animationDelay: `${i * 0.05}s` }}>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ background: "rgba(129,140,248,0.12)" }}>
                    <BookOpen className="w-3.5 h-3.5" style={{ color: "#818cf8" }} />
                  </div>
                  <div>
                    <p className="text-sm font-medium leading-tight" style={{ color: "var(--text-primary)" }}>{loan.bookTitle}</p>
                    <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>{loan.memberName} · Due {formatDate(loan.dueDate)}</p>
                  </div>
                </div>
                <Badge variant={loan.status === "active" ? "info" : loan.status === "overdue" ? "danger" : "success"}>
                  {loan.status}
                </Badge>
              </div>
            ))}
          </div>
        </Card>

        {/* Side cards */}
        <div className="space-y-4">
          <Card className="p-5">
            <div className="flex items-center gap-2 mb-4">
              <IndianRupee className="w-4 h-4" style={{ color: "#f87171" }} />
              <p className="font-semibold text-sm" style={{ color: "var(--text-primary)" }}>Outstanding Fines</p>
            </div>
            <div className="text-center py-2">
              <p className="text-4xl font-bold" style={{ color: "#f87171" }}>{formatCurrency(stats?.totalFines ?? 0)}</p>
              <p className="text-xs mt-2 px-3 py-1 rounded-lg inline-block" style={{ color: "#f87171", background: "rgba(248,113,113,0.1)" }}>
                unpaid fines total
              </p>
            </div>
          </Card>

          <Card className="p-5">
            <p className="font-semibold text-sm mb-4" style={{ color: "var(--text-primary)" }}>Low Stock Alert</p>
            <div className="space-y-2.5">
              {lowStock.slice(0, 4).map((book) => (
                <div key={book._id} className="flex items-center justify-between gap-2">
                  <p className="text-xs truncate flex-1" style={{ color: "var(--text-secondary)" }}>{book.title}</p>
                  <Badge variant={book.availableCopies === 0 ? "danger" : "warning"}>
                    {book.availableCopies === 0 ? "Out" : `${book.availableCopies} left`}
                  </Badge>
                </div>
              ))}
              {lowStock.length === 0 && <p className="text-xs text-center py-2" style={{ color: "var(--text-muted)" }}>All books in stock ✓</p>}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
